N = int(input("total students: "))
marks = [int(input("marks: "))for i in range(N)]

def Quicksort(arr,left,right):
    if left<right:
        partition_pos = partition(arr,left,right)
        Quicksort(arr,left,partition_pos-1)
        Quicksort(arr,partition_pos+1,right)
        
def partition(arr,left,right):
    i = left
    j = right-1
    pivot = arr[right]
    while i < j:
        while i<right and arr[i]<pivot:
            i = i+1
        while j>left and arr[j]>pivot:
            j = j-1
        if i<j:
            arr[i],arr[j] = arr[j],arr[i]
    if arr[i]>pivot:
        arr[right],arr[i] = arr[i],arr[right]
    return i

Quicksort(marks,0,len(marks)-1)
print("The sorted array is: ",marks)
print()
marks = marks[::-1]
print("\nTop 5 marks are: ",marks[0:5])
