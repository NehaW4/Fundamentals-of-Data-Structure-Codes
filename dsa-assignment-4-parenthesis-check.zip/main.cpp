#include<iostream>
using namespace std;

class Para {   
    int size;
    char stack[100];
    int top = -1;
    
    public:
        bool isEmpty();
        bool isFull();
        void push(char c);
        void pop();
        void checkParenthesis();
};

bool Para::isEmpty(){
	if(top==-1){
		return true;
	}
	else{
		return false;
	}
}

bool Para::isFull(){
	if(top==100){
		return true;
	}
	else{
		return false;
	}
}

void Para::push(char ch){
	if(isFull()==0){
		top++;
		stack[top]=ch;
    }
}

void Para::pop(){
	if(!isEmpty()){
		top--;
	}
}

void Para::checkParenthesis(){
    int size;
    char string[100],x;
    cout<<"Enter the size of String: "<<endl;
    cin>>size;
    cout<<"Enter the String"<<endl;
    cin>>string;
    for(int i=0;i<=size;i++){
        x=string[i];
        if((x =='(') || (x=='{') || (x=='['))
        {
            push(x);  
        }
    	else if((x ==')') || (x=='}') || (x==']'))
    	{
            if(isEmpty()){
            	push(x);
            }
            else if(stack[top]=='(' && x ==')'){
                pop();
            }
            else if(stack[top]=='{' && x =='}'){
                pop();
            }
            else if(stack[top]=='[' && x ==']'){
                pop();
            }
            else if((x ==')') || (x=='}') || (x==']')){
            	push(x);
    		}
        }
    }   
    if(!isEmpty()){
        cout<<"Not Well Partgensizes equation";
    }
    else{
        cout<<"Well Partgensizes Equation";
    }    
}

int main()
{
	int choice;
	do{
		Para s;
		s.checkParenthesis();
		cout<<"\nDO you want to continue?{1/0)";
		cin>>choice;
	}while(choice!=0);
	return 0;
}





