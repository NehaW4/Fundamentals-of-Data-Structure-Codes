N = int(input("enter total number of students: "))
marks = [float(input("Enter marks of students: "))for i in range(N)]

def Bubble_sort(marks):
    for i in range(N):
        for j in range(N-1):
            if marks[j]>marks[j+1]:
                marks[j],marks[j+1]=marks[j+1],marks[j]
    print("sorted list of marks is: ",marks)
    print("top five scores : \n")
    for i in range(N-5,N,1):
        print(marks[i])
    
def Selection_sort(marks,N):
    for i in range(0,N-1):
        for j in range(i+1,N):
            if marks[i]>marks[j]:
                marks[i],marks[j]=marks[j],marks[i]
    print("Sorted list is : ",marks)
    
print("\nEnter choice\n1.Bubble sort\n2.Selection sort\n")
ch=int(input("choice: "))
if ch==1:
    Bubble_sort(marks)
else:
    Selection_sort(marks,N)
    
    

