"""Write a Python program to store marks scored in subject “Fundamental of Data
Structure” by N students in the class. Write functions to compute following:
a) The average score of class
b) Highest score and lowest score of class
c) Count of students who were absent for the test
d) Display mark with highest frequency"""

Total_student=int(input("How many students are in Class?-->"))
S=[]
for i in range(Total_student):
    data=input("Name of the student "+str(i+1)+" is:")
    S.append(data)
print("Students in class:",S)

marks_scored=[]
absent_student=[]
total=0
for i in S:
    marks=eval(input("Marks scored by student  "+ i +  " in FDS test is:(put marks -1 for Absent students):"))
    if marks==-1:
        absent_student.append(i)
    else:
        marks_scored.append(marks)
        total+=marks
Average=total/(len(marks_scored))
print("Average of Score of the class :",Average)


#2..To print higesht and lowest Score
max_score=marks_scored[0]
min_score=marks_scored[0]
for mark in marks_scored:
    if mark<min_score:
        min_score=mark;
    if max_score<mark:
        max_score=mark;
print("Highest score of class is:",max_score)
print("Lowest score of class is:",min_score)

#mark with highest frequency
maximum=0
result=marks_scored[0]
for i in marks_scored:
    freq=marks_scored.count(i)
    if freq>maximum:
        maximum=freq
        result=i
    
print("Mark with Higest Frequency:"+ str(result))
print("No. of students absent for FDS test:",len(absent_student))
print("Name of students who were absent for the test are: ",absent_student)







