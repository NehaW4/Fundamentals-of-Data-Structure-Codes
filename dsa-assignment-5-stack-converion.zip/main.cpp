#include<iostream>
using namespace std;

class Converstion{
    char stack[100];
    int top = -1;
    public:
        bool isEmpty();
        bool isFull();
        void push(char c);
        void pop();
        string intopostfix();
        int priority(char s);
        bool isOperator(char l);
};

bool Converstion::isEmpty(){
    if(top==-1){
        return true;
	}
    else{
        return false;
	}
}
bool Converstion::isFull(){
    if(top==100){
    	return true;
	}
    else{
    	return false;
	}
}

void Converstion::push(char ch){
    if(isFull()==0){
        top++;
        stack[top]=ch;
    }
}

void Converstion::pop(){
    if(!isEmpty()){
        top--;
    }
}
int Converstion :: priority(char s){
	if(s=='/' || s=='*' ){
		return 2;			
	}
	else if(s=='+'|| s=='-'){
		return 1;
	}
	else if(s=='^'){
		return 0;
	}
	else{
		return -1;
	}
}
bool Converstion :: isOperator(char l) {
	if(l == '+' || l == '-' ||l == '*' || l == '/' || l == '^' || l == '(' || l == ')'){
		return true;
	}
	else{
		return false;
	} 
}
string Converstion :: intopostfix(){
    
	string infix;
	string postfix;
	cout<<"Enter the infix equation : ";
	cin>>infix;
	
	for(int i=0; i<infix.length(); i++)
	{
		if(infix[i] == '(')
		{
			push(infix[i]);
		}
		else if(!isOperator(infix[i]))
		{
			postfix+=infix[i];
		}
		else if(infix[i]==')')
		{
			while(stack[top] != '('){
				postfix +=stack[top];
				pop();
			}
			if(stack[top] =='('){
				pop();
			}
		}
		else if(isOperator(infix[i]))
		{
			if(isEmpty())
			{	
				push(infix[i]);	
			}
			else 
			{
				if(priority(infix[i])>priority(stack[top]))
				{
					push(infix[i]);
				}
				else if((priority(infix[i])<=priority(stack[top])))
				{
					do{
						postfix += stack[top];
						pop();
					}while((priority(infix[i])<=priority(stack[top])));
					push(infix[i]);	
				}			
			}
		}
	}
	while(!isEmpty()){
        postfix+=stack[top];
        pop();
    }
    cout<<"POSTFIX EXPRESSION IS : "<<postfix;
    return postfix;   
}

int main()
{
	int choice;
	do
	{ 
		Converstion s;
		s.intopostfix();
		cout<<"\nDO you want to continue?{1/0)";
		cin>>choice;
	}while(choice!=0);
	return 0;
}

