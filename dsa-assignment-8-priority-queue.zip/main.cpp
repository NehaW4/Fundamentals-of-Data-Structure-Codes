#include<iostream>
using namespace std;
class PriorityQueue
{
	private:
	    int front,rear;
	    int arr[5];
	    int p_arr[5];
	    
	public:
		PriorityQueue()
		{
			front=-1;
			rear=-1;
			for(int i=0;i<5;i++)
			{
				arr[i]=0;
			}
		}
		bool isEmpty();
		bool isFull();
		void enqueue(int val,int pr);
		int dequeue();
		void display();
};

bool PriorityQueue::isEmpty()
{
	if(front==-1 && rear==-1)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool PriorityQueue::isFull()
{
	if(rear==4)
	{
		return true;
	}
	else
	{
		return false;
	}
}
void PriorityQueue::enqueue(int val,int pr)
{
	if(isFull())
	{
		cout<<"Queue is full\n";
	}
	else if(isEmpty())
	{
		front=0;
		rear=0;
		arr[rear]=val;
		p_arr[rear]=pr;
	}
	else
	{
		int i;
		for(i=rear;i>=front;i--)
		{
			if(pr<=p_arr[i])
			{
				arr[i+1]=arr[i];
				p_arr[i+1]=p_arr[i];
			}
			else
			{
				break;
			}
		}
		arr[i+1]=val;
		p_arr[i+1]=pr;
		rear++;
	}
}
int PriorityQueue::dequeue()
{
	int x;
	if(isEmpty())
	{
		cout<<"Queue is empty\n";
		return 0;
	}
	else if(front==rear)
	{
		x=arr[front];
		arr[front]=0;
		front=-1;
		rear=-1;
		return x; 
	}
	else
	{
		x=arr[front];
		arr[front]=0;
		front++;
		return x;
	}
}
void PriorityQueue::display()
{
	if(isEmpty())
	{
		cout<<"Queue is empty\n";
	}
	else
	
	{
		for(int i=front;i<=rear;i++)
		{
			cout<<"Job id:- "<<arr[i]<<" ["<<p_arr[i]<<"]"<<endl;
		}
	}
}
int main()
{
	PriorityQueue q;
	int ch,val,pr;
	do
	{
		cout<<"\n-----MENU-----\n";
		cout<<"1.Add job\n";
		cout<<"2.Delete job\n";
		cout<<"3.Display job\n";
		cout<<"4.EXIT\n";
		cin>>ch;
		switch(ch)
		{
			case 1:
				cout<<"\nEnter job ID : \n";
				cin>>val;
				cout<<"Enter priority:\n";
				cin>>pr;
				q.enqueue(val,pr);
				break;
			case 2:
				cout<<"Deleted job is:- "<<q.dequeue()<<endl;
				break;
			case 3:
				q.display();
				break;
			case 4:
				break;
		}
	}while(ch!=4);
	return 0;
}
