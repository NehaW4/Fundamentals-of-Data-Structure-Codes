#include <iostream>
using namespace std;

class Queue{
    
	private:
		int front;
		int rear;
		int arr[5];
		
	public:
		Queue(){
			front = -1;
			rear = -1;
			for(int i = 0;i<5;i++)
			{
				arr[i] = 0;
			}
		}
		bool isFull();
		bool isEmpty();
		void enQueue(int val);
		int deQueue();
		void display();
};

bool Queue :: isFull(){
	if(rear == 4){
		return true;
	}
	else{
		return false;
	}
}

bool Queue :: isEmpty(){
	if(rear == -1 and front == -1){
		return true;
	}
	else{
		return false;
	}
}

void Queue :: enQueue(int val){
	if(isFull()){
		cout<<"Queue full"<<endl;	
	}
	else if(isEmpty()){
		front =  0;
		rear = 0;
		arr[rear] = val;
	}
	else{
		rear++;
		arr[rear] = val;
	}
}

int Queue :: deQueue(){
	int x;
	if(isEmpty()){
		cout<<"Queue Empty"<<endl;
		return 0;
	}
	else if(front == rear){
		x = arr[front];
		arr[front] = 0;
		front = -1;
		rear = -1;
		return x;
	}
	else{
		x = arr[front];
		arr[front] = 0;
		front++;
		return x;
	}
}

void Queue :: display()
{
	cout<<"Job Queue is Here "<<endl;
	for(int i=front; i<=rear;i++)
	{
		cout<<"Items are -> "<<arr[i]<<" "<<endl;
	}
}

int main(){
	Queue q;
	int choice,value;
	do{
		cout<<"-------Menu--------"<<endl;
		cout<<"1). Add a Job"<<endl;
		cout<<"2). Delete a Job"<<endl;
		cout<<"3). Display Jobs"<<endl;
		cout<<"4). Exit"<<endl;
		cout<<"Enter your choice : ";
		cin>>choice;
		
		switch(choice){
			case 1:
				cout<<"Enter the Job ID to add : ";
				cin>>value;
				q.enQueue(value);
				break;
			case 2:
				cout<<"Dequeued element is --> "<<q.deQueue()<<endl;
				break;
			case 3:
				q.display();
				break;
			case 4:
				break;
			default:
				cout<<"Invalid";
				break;
		}
	}while(choice != 4);
	return 0;
}







