"""      Write a Python program to compute following computation on matrix:
a) Addition of two matrices B) Subtraction of two matrices
c) Multiplication of two matrices d) Transpose of a matrix    """

row = int(input("Enter number of rows : "))
col = int(input("Enter number of columns : "))

# Matrix ONE inputs
print("Matrix ONE ")
matrix_1 = [[int(input(f"Enter the element in pocket {[i+1]}{[j+1]}")) for j in range(col)]for i in range(row)]

# Matrix TWO inputs
matrix_2 = [[int(input(f"Enter the element in pocket {[i+1]}{[j+1]}")) for j in range(col)]for i in range(row)]
print()
print("-------------Matrix ONE-----------------------------")
print() 
for i in range(row):
    for j in range(col):
        print(matrix_1[i][j]," ",end="")
    print()
    
print()
print("-------------Matrix TWO-----------------------------")
print() 
for i in range(row):
    for j in range(col):
        print(matrix_2[i][j]," ",end="")
    print()
    
#Result Matrix for Addition

result_addition = [[0 for j in range(col)]for i in range(row)]
result_sub = [[0 for j in range(col)]for i in range(row)]
result_trans = [[0 for j in range(col)]for i in range(row)]
result_mult = [[0 for j in range(col)]for i in range(row)]

for i in range(row):
    for j in range(col):
        result_addition[i][j] = matrix_1[i][j] + matrix_2[i][j]
        result_sub[i][j] =  matrix_1[i][j] - matrix_2[i][j]
print()
print("-------------Addition of matrix-----------------------------")
print()       
for i in range(row):
    for j in range(col):
        print(result_addition[i][j]," ",end="")
    print()
#Substraction of matrix
print()
print("-------------Substraction of matrix-----------------------------")
print()
for i in range(row):
    for j in range(col):
        print(result_sub[i][j]," ",end="")
    print()
print()
print("-------------Transpose of Matrix ONE-----------------------------")
print()
for i in range(len(matrix_1)):
    for j in range(len(matrix_1[0])):
        result_trans[j][i] = matrix_1[i][j]
for i in range(row):
    for j in range(col):
        print(result_trans[i][j]," ",end="")
    print()
print()
print("-------------Multiplication of matrix-----------------------------")
print()

for i in range(len(matrix_1)):
    for j in range(len(matrix_2[0])):
        for k in range(len(matrix_2)):
            result_mult[i][j] += matrix_1[i][j] * matrix_2[k][j]

for i in range(len(result_mult)):
    for j in range(len(result_mult[0])):
        print(result_mult[i][j]," ",end="")
    print()
















    



