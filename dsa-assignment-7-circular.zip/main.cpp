#include<iostream>
using namespace std;
class CircularQueue
{
	private:
	    int front,rear;
	    int arr[5];
	    
	public:
		CircularQueue()
		{
			front=rear=-1;
			for(int i=0;i<5;i++)
			{
				arr[i]=0;
			}
		}
		bool isEmpty();
		bool isFull();
		void enqueue(int val);
		int dequeue();
		void display();
};
bool CircularQueue::isEmpty()
{
	if(front==-1 && rear==-1)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool CircularQueue::isFull()
{
	if(front==(rear+1)%5)
	{
		return true;
	}
	else
	{
		return false;
	}
}
void CircularQueue::enqueue(int val)
{
	if(isFull())
	{
		cout<<"The queue is full, no more orders can be accepted\n";
	}
	else if(isEmpty())
	{
		front=0;
		rear=0;
		arr[rear]=val;
	}
	else
	{
		rear=(rear+1)%5;
		arr[rear]=val;
	}
}
int CircularQueue::dequeue()
{
	int x;
	if(isEmpty())
	{
		cout<<"No orders in the queue\n";
		return 0;
	}
	else if(front==rear)
	{
		x=arr[front];
		arr[front]=0;
		front=-1;
		rear=-1;
		return x;
	}
	else
	{
		x=arr[front];
		arr[front]=0;
		front=(front+1)%5;
		return x;
	}
}
void CircularQueue::display()
{
	for(int i=0;i<5;i++)
	{
		cout<<"your order code is: "<<arr[i]<<endl;
	}
}
int main()
{
	int ch,val;
	CircularQueue c;
	do
	{
		cout<<"-----MENU-----\n";
		cout<<"\n1.Place order\n";
		cout<<"2.Deliver order\n";
		cout<<"3.Display order queue\n";
		cout<<"4.EXIT\n";
		cin>>ch;
		switch(ch)
		{
			case 1:
				cout<<"-----PIZZA MENU-----\n";
				cout<<"1.paneer pizza\n";
				cout<<"2.onion pizza\n";
				cout<<"3.margreta pizza\n";
				cout<<"4.double cheese pizza\n";
				cin>>val;
				if(val>4)
				{
					cout<<"Enter correct choice\n";
					break;
				}
				else
				{
					c.enqueue(val);
				}
				break;
			case 2:
				cout<<"Delivered pizza - "<<c.dequeue()<<endl;
				break;
			case 3:
				cout<<"Placed orders are\n";
				c.display();
				break;
			case 4:
				break;
				
		}
	}while(ch!=4);
	return 0;
}
