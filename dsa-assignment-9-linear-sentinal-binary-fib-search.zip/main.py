total_num = int(input("Enter Total numbers of Student : "))
rollno=[int(input("Enter the roll numbers in Sorted mannaer that are present : ")) for i in range(total_num)]
roll=int(input("Enter the Roll num for which you have to check :"))
    

def linear_searching(rollno,total_num,roll):
    
    for i in range (total_num):
        if(rollno[i] == roll):
            print("Roll number is present")
            break
    else:
        rollno[total_num-1]=roll
        print("Roll number is present at last Serched by Sentinal searching")
        print (rollno)
        
linear_searching(rollno,total_num,roll)












"""
#Binary searching..........................................

def binary_seraching(roll_call,rollNum,total_num):
    first = 0
    last =total_num -1

    while(first <= last):
        mid =(first+last)//2
        if(roll_call[mid] == rollNum):
            return True
        else:
            if(roll_call[mid] > rollNum):
                last = mid-1
            else:
                first = mid+1
    return False           




#Fibonacci searching-..........................................

def fibonacci_search(arr,target):
    size = len(arr)
    
    start = -1
    f0 = 0 
    f1 = 1 
    f2 = 1 
    
    while(f2 < size):
        f0 = f1
        f1 = f2
        f2 = f1 + f0 
        print("While Loop")
        print(f0,f1,f2)    
    while (f2 > 1):
        index = min(start + f0,size -1)
        if arr[index] < target:
            print("if condtion 1")
            print(f0,f1,f2) 
            f2 = f1
            f1 = f0
            f0 = f2 - f1
            start = index
            print("if Condition 2")
            print(f0,f1,f2) 
        elif arr[index] > target:
            print("else Condition 1")
            print(f0,f1,f2) 
            f2 = f0
            f1 = f1 - f0
            f0 = f2 - f1
            print("else Condition 2")
            print(f0,f1,f2) 
        else:
            return print("Element found at index",index)
            
    if f1 and arr[size - 1] == target :
       return print("Element found at index ",size-1)
    else:   
        return print("Elements is Not found")

  


print("Enter the choice for selecting sreaching : \n 1.Linear as well as Sentinal \n 2. Binary Serach \n 3.Fibonacci searching ")
choice=int(input(" "))
if(choice==1):
    linear_searching(roll_call,num,rollnum)
elif(choice==2):
    if(binary_seraching(roll_call,rollnum,num) == True):
        print("Element found")
    else:
        print("Element is Not found")
elif(choice==3):        
    print(fibonacci_search(roll_call,rollnum))



"""




   












